import cv2 as cv
img = cv.imread('A.png')
cv.rectangle(img,(200,200),(400,400),(255,255,0),2)
cv.imshow('image',img)
cv.waitKey(0)
cv.destoryAllWindows()